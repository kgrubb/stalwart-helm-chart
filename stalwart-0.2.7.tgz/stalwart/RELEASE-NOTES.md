## [0.2.7] - 2026-06-13

### Changed
- Chart update

