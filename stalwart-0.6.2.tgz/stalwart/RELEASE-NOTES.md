## [0.6.2] - 2026-06-28

### Fixed
- use exec probes for management health checks ([#26](https://github.com/kgrubb/stalwart-helm-chart/pull/26))
  - Replace kubelet `httpGet` liveness/readiness probes with `exec` probes that `curl` the management health endpoints on `127.0.0.1`.
  - On k3s/Flannel, probes from the node bridge to the pod IP can fail with connection reset/EOF while Stalwart is healthy, causing CrashLoopBackOff.

