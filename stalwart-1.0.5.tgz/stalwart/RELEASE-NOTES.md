## [1.0.5] - 2026-10-29

### Fixed
- bump Stalwart app image to v1.0.1

