## [0.7.14] - 2026-08-18

### Fixed
- bump Stalwart app image to v0.16.18

