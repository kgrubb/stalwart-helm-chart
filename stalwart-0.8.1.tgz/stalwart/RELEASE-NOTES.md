## [0.8.1] - 2026-10-19

### Fixed
- bump Stalwart app image to v0.16.27

