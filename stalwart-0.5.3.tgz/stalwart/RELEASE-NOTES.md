## [0.5.3] - 2026-06-26

### Changed
- Chart update

