## [1.0.6] - 2026-11-03

### Fixed
- bump Stalwart app image to v1.0.2

