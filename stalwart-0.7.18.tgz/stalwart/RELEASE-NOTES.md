## [0.7.18] - 2026-09-14

### Fixed
- bump Stalwart app image to v0.16.22

