## [0.2.8] - 2026-06-13

### Fixed
- generate changelog from squash-merged PR commits ([#21](https://github.com/kgrubb/stalwart-helm-chart/pull/21))
  - Read PR numbers from squash commit subjects instead of merge commits
  - Skip chore(release) bot commits
  - Map chore, docs, and ci prefixes to Changed

