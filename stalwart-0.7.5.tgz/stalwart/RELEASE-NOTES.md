## [0.7.5] - 2026-07-01

### Changed
- Chart update

