## [1.0.7] - 2026-11-05

### Fixed
- bump Stalwart app image to v1.0.3

