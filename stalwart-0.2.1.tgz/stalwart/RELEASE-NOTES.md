## [0.2.1] - 2026-06-13

### Changed
- Chart update

