## [0.2.4] - 2026-06-13

### Changed
- Chart update

