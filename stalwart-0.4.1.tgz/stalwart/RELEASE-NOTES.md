## [0.4.1] - 2026-06-26

### Changed
- Chart update

