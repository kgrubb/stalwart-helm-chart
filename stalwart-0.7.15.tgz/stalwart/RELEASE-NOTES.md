## [0.7.15] - 2026-08-25

### Fixed
- bump Stalwart app image to v0.16.19

