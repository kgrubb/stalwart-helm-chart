## [0.6.0] - 2026-06-26

### Changed
- Chart update

