## [0.2.3] - 2026-06-13

### Changed
- Chart update

