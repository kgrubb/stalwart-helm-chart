## [0.9.5] - 2026-10-27

### Changed
- Chart update

