## [0.7.6] - 2026-07-07

### Changed
- Chart update

