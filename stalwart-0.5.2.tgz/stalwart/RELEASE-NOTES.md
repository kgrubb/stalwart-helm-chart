## [0.5.2] - 2026-06-26

### Changed
- Chart update

