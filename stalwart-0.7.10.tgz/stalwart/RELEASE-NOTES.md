## [0.7.10] - 2026-07-21

### Fixed
- bump Stalwart app image to v0.16.14

