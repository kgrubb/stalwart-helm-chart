## [0.7.17] - 2026-09-07

### Fixed
- bump Stalwart app image to v0.16.21

