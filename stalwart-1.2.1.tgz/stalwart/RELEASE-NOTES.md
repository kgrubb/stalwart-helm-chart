## [1.2.1] - 2026-11-26

### Fixed
- bump Stalwart app image to v1.2.1

