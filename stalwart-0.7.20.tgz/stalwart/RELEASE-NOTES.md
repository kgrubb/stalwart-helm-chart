## [0.7.20] - 2026-09-28

### Fixed
- bump Stalwart app image to v0.16.24

