## [0.7.13] - 2026-08-11

### Fixed
- bump Stalwart app image to v0.16.17

