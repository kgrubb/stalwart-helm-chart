## [1.1.0] - 2026-11-10

### Added
- bump Stalwart app image to v1.1.0

