## [0.7.11] - 2026-07-28

### Fixed
- bump Stalwart app image to v0.16.15

