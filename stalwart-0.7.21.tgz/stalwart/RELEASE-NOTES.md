## [0.7.21] - 2026-09-30

### Changed
- one-shot copy GPG secret to nostalgiatv ([#34](https://github.com/kgrubb/stalwart-helm-chart/pull/34))
  - Temporary workflow_dispatch to copy `GPG_PRIVATE_KEY` from this repo into `kgrubb/nostalgiatv-helm-chart`
  - Uses short-lived `TEMP_CROSS_REPO_TOKEN` Actions secret
  - Will be removed after the copy succeeds
- add one-shot workflow to copy GPG secret

