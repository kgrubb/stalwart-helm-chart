## [1.1.1] - 2026-11-17

### Fixed
- bump Stalwart app image to v1.1.1

