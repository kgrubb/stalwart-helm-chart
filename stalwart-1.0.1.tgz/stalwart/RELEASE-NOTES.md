## [1.0.1] - 2026-10-29

### Fixed
- grant `statefulsets/scale` on the hooks Role so migrate prepare can scale the mail StatefulSet to 0 ([#44](https://github.com/kgrubb/stalwart-helm-chart/pull/44))
- allow migrate hooks to scale StatefulSets

