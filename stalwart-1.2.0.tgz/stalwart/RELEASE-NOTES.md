## [1.2.0] - 2026-11-24

### Added
- bump Stalwart app image to v1.2.0

