## [0.7.22] - 2026-10-12

### Changed
- Removes the temporary `copy-gpg-secret.yml` workflow after a successful copy to `kgrubb/nostalgiatv-helm-chart` ([#35](https://github.com/kgrubb/stalwart-helm-chart/pull/35))
- remove one-shot GPG copy workflow

### Fixed
- bump Stalwart app image to v0.16.26
- bump Stalwart app image to v0.16.25

