## [0.4.0] - 2026-06-26

### Added
- add recovery admin existingSecret and OIDC bootstrap ([#24](https://github.com/kgrubb/stalwart-helm-chart/pull/24))

