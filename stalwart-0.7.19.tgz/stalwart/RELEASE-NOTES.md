## [0.7.19] - 2026-09-22

### Fixed
- bump Stalwart app image to v0.16.23

