## [0.7.12] - 2026-08-03

### Fixed
- bump Stalwart app image to v0.16.16

