## [0.7.16] - 2026-08-31

### Fixed
- bump Stalwart app image to v0.16.20

