## [0.2.5] - 2026-06-13

### Changed
- Chart update

