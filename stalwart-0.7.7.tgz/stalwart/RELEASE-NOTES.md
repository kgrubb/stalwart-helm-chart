## [0.7.7] - 2026-07-07

### Changed
- Chart update

