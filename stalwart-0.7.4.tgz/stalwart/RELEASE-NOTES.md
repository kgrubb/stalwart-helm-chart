## [0.7.4] - 2026-07-01

### Changed
- Chart update

