## [0.7.9] - 2026-07-13

### Fixed
- bump Stalwart app image to v0.16.13

